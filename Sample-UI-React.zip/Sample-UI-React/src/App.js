import React from "react";
import "./App.scss";
import "./icons.css";
import Plutus from "./Components/Plutus/Plutus";


function App() {
  return (
      <div className="App">
        <Plutus/>
      </div>
  );
}

export default App;
