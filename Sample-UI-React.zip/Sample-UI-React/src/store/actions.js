export const CURRENT_USER = "CURRENT_USER";
export const TOGGLE_MENU = "TOGGLE_MENU";
export const TOGGLE_MOBILE_MENU = "TOGGLE_MOBILE_MENU";
export const TOGGLE_ACCORDION = "TOGGLE_ACCORDION";
export const MOBILE_VIEW = "MOBILE_VIEW";
export const SET_RECORDS = "SET_RECORDS";
export const SET_ACTIVE_STEP_RECORDS = "SET_ACTIVE_STEP_RECORDS";
export const SET_BOOKS_RADIO = "SET_BOOKS_RADIO";
export const SET_SELECTED_ISSUEID = "SET_SELECTED_ISSUEID";
export const SET_SELECTED_TASKID = "SET_SELECTED_TASKID";
export const SET_SELECTED_EXCEPTIONID = "SET_SELECTED_EXCEPTIONID";
export const SET_APP_DETAILS = "SET_APP_DETAILS";
export const SET_ROLES = "SET_ROLES";
export const SET_PREV_PAGE = "SET_PREV_PAGE";

export function setUserObj(userObj) {
  return { type: CURRENT_USER, payload: userObj };
}

export function setToggleMenu(isMenuExpanded) {
  return { type: TOGGLE_MENU, payload: isMenuExpanded };
}

export function setToggleMobileMenu(isMobileMenu) {
  return { type: TOGGLE_MOBILE_MENU, payload: isMobileMenu };
}

export function setAccordion(isAccordionOpen) {
  return { type: TOGGLE_ACCORDION, payload: isAccordionOpen };
}

export function setMobileView(isMobileView) {
  return { type: MOBILE_VIEW, payload: isMobileView };
}

export function setRecords(records) {
  return { type: SET_RECORDS, payload: records };
}

export function setActiveStepBooksAndRecords(activeStep) {
  return { type: SET_ACTIVE_STEP_RECORDS, payload: activeStep };
}

export function setRadioBooksAndRecords(radio) {
  return { type: SET_BOOKS_RADIO, payload: radio };
}

export function setSelectedIssueId(selectedIssueId) {
  return { type: SET_SELECTED_ISSUEID, payload: selectedIssueId };
}

export function setSelectedExceptionId(selectedExceptionId) {
  return { type: SET_SELECTED_EXCEPTIONID, payload: selectedExceptionId };
}

export function setPrevPage(prevPage) {
  return { type: SET_PREV_PAGE, payload: prevPage };
}

export function setSelectedTaskId(selectedTaskId) {
  return { type: SET_SELECTED_TASKID, payload: selectedTaskId };
}

export function setRoles(role) {
  return { type: SET_ROLES, payload: role };
}
export function setAppDetails(appDetails) {
  return { type: SET_APP_DETAILS, payload: appDetails };
}
