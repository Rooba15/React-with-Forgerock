import { combineReducers } from "redux";
import uiReducer from "./uiReducer";
import dataReducer from "./dataReducer";

const rootReducer = combineReducers({
  ui: uiReducer,
  data: dataReducer
});

export default rootReducer;
