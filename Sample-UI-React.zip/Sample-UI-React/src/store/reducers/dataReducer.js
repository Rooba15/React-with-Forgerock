import {
  TOGGLE_MOBILE_MENU,
  SET_RECORDS,
  SET_SELECTED_ISSUEID,
  SET_SELECTED_TASKID,
  SET_SELECTED_EXCEPTIONID,
  SET_APP_DETAILS,
  SET_ROLES,
  SET_PREV_PAGE,
} from "../actions";
import { initState } from "./initState";

function dataReducer(state = initState.data, action) {
  switch (action.type) {
    case TOGGLE_MOBILE_MENU:
      return { ...state, isMobileMenu: action.payload };
    case SET_RECORDS:
      return { ...state, records: action.payload };
    case SET_SELECTED_ISSUEID:
      return { ...state, selectedIssueId: action.payload };
    case SET_SELECTED_EXCEPTIONID:
      return { ...state, selectedExceptionId: action.payload };
    case SET_PREV_PAGE:
      return { ...state, prevPage: action.payload };
    case SET_SELECTED_TASKID:
      return { ...state, selectedTaskId: action.payload };
    case SET_ROLES:
      return { ...state, roleObj: action.payload };
    case SET_APP_DETAILS:
      return { ...state, appDetails: action.payload };
    default:
      return state;
  }
}

export default dataReducer;
