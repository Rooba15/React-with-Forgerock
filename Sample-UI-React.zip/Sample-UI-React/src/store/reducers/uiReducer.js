import { CURRENT_USER, TOGGLE_MENU, TOGGLE_ACCORDION, MOBILE_VIEW, SET_ACTIVE_STEP_RECORDS, SET_BOOKS_RADIO, SET_RECORDS } from "../actions";
import { initState } from "./initState";

function uiReducer(state = initState.ui, action) {
  switch (action.type) {
    case CURRENT_USER:
      return { ...state, userObj: action.payload };
    case TOGGLE_MENU:
      return { ...state, isMenuExpanded: action.payload };
    case TOGGLE_ACCORDION:
      return { ...state, isAccordionOpen: action.payload };
    case MOBILE_VIEW:
      return { ...state, isMobileView: action.payload };
    case SET_ACTIVE_STEP_RECORDS:
      return { ...state, activeStep: action.payload };
    case SET_BOOKS_RADIO:
      return { ...state, radio: action.payload };
    case SET_RECORDS:
      return { ...state, records: action.payload };
    default:
      return state;
  }
}

export default uiReducer;
