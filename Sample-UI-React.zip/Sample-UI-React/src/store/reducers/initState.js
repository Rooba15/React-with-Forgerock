export const initState = {
  ui: {
    isMenuExpanded: false,
    isAccordionOpen: false,
    isMobileView: false
  },
  data: {
    isMobileMenu: false,
  }
};
