import React from "react";
import "../../Global/Styles.scss";

export const PrimaryButton = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-blue" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const SecondaryButton = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-white" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const DisabledButton = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-disabled" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const PrimaryButtonLarge = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-large btn-blue" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const SecondaryButtonLarge = ({ children, type, onClick, disabled }) => {
  return (
    <button className="btn btn-large btn-white" onClick={onClick} type={type} disabled={disabled}>
      {children}
    </button>
  );
};

export const PrimaryButtonMedium = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-medium btn-blue" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const SecondaryButtonMedium = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-medium btn-white" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const SecondaryButtonPicBig = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-secondary-pic-big" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const GreenActionButton = ({ className, children, type, onClick }) => {
  return (
    <button className={className} onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const SecondaryButtonPicSmall = ({ children, type, onClick, disabled }) => {
  return (
    <button
      className="btn btn-secondary-pic-small"
      onClick={onClick}
      type={type}
      disabled={disabled}
    >
      {children}
    </button>
  );
};

export const SmallButton = ({ className, children, type, onClick }) => {
  return (
    <button className={className} onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const OverflowBtn = ({ children, type, onClick }) => {
  return (
    <button className="btn btn-overflow" onClick={onClick} type={type}>
      {children}
    </button>
  );
};

export const IconButton = ({ className, children, type, onClick }) => {
  return (
    <button className={className} onClick={onClick} type={type}>
      {children}
    </button>
  );
};
