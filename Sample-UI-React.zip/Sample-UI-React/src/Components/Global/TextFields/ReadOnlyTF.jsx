import React from 'react';
import TextField from '@material-ui/core/TextField';
import "../../Global/Styles.scss";

export const ReadOnlyTF = ({
    defaultValue,
    label
}) => {

    return (
        <form noValidate autoComplete="off">
            <TextField 
                id="standard-basic" 
                defaultValue={defaultValue}
                label={label}
                multiline
                rowsMax="4"
                margin="normal"
                InputProps={{
                  readOnly: true,
                }}
            />
        </form>
    );
};

