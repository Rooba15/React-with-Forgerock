import React from 'react';
import TextField from '@material-ui/core/TextField';
import "../../Global/Styles.scss";

export const SingleLineTF = ({
    className,
    label,
    value,
    name,
    onChange,
    helperText
}) => {

    return (
        <form noValidate autoComplete="off">
            <TextField 
                id="standard-basic" 
                label={label}
                className={className}
                helperText={helperText}
                onChange={onChange}
                value={value}
                name={name}
            />
      </form>
    );
};

