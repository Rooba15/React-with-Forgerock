import React from 'react';
import TextField from '@material-ui/core/TextField';
import "../../Global/Styles.scss";

export const MultiLineTF = ({
    label,
    className,
    value,
    name,
    onChange,
    onBlur,
    helperText,
    disabled
}) => {

    return (
        <TextField
            label={label}
            className={className}
            value={value}
            name={name}
            onChange={onChange}
            onBlur={onBlur}
            multiline
            rowsMax="3"
            helperText={helperText}
            margin="normal"
            disabled={disabled}
        />
    );
};
