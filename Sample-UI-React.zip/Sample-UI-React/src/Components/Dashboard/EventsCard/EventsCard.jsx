import React, { Component } from "react";
import { Modal } from "react-bootstrap";
import "./EventsCard.scss";
import { EVENTS } from "../../../properties";

class EventsCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModal: false,
      isEventIndex: -1
    };
    this.toggleReadMoreModal = this.toggleReadMoreModal.bind(this);
  }

  toggleReadMoreModal(index) {
    this.setState({
      isEventIndex: index,
      isModal: !this.state.isModal
    });
  }

  render() {
    const { isModal, isEventIndex } = this.state;
    return (
      <div>
        {EVENTS.map((event, index) => (
          <div key={index} className="card Event-Card">
            <div className="event-date-div">
              <div className="event-date-month">{event.month}</div>
              <div className="event-date-day">{event.date}</div>
            </div>
            <div className="event-content-div card-body">
              <div className="event-title">{event.title}</div>
              <div className="event-description">{event.description}</div>
              <div
                className="event-modal"
                onClick={() => this.toggleReadMoreModal(index)}
              >
                Read more
              </div>
            </div>

            {isModal === true && isEventIndex === index && (
              <Modal.Dialog className="readMoreModal">
                <Modal.Header closeButton onClick={this.toggleReadMoreModal}>
                  <Modal.Title>{event.title}</Modal.Title>
                </Modal.Header>
                <Modal.Body className="readMoreModalContent">
                  <div className="readMoreModalMessage">
                    {event.description}
                  </div>
                </Modal.Body>
              </Modal.Dialog>
            )}
          </div>
        ))}
      </div>
    );
  }
}

export default EventsCard;
