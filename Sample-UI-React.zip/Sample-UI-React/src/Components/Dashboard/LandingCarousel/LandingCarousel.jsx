import React, { Component } from "react";
import { Carousel } from "react-bootstrap";
import carousel_img_1 from "../../../assets/images/carousel_img_1.png";
import carousel_img_2 from "../../../assets/images/carousel_img_2.png";
import carousel_img_3 from "../../../assets/images/carousel_img_3.png";
import "./LandingCarousel.scss";

class LandingCarousel extends Component {
  render() {
    return (
      <div className="Landing-Carousel">
        <Carousel controls={false} pauseOnHover={false} interval={3000}>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src={carousel_img_1}
              alt="First slide"
            />
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src={carousel_img_2}
              alt="Second slide"
            />
          </Carousel.Item>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src={carousel_img_3}
              alt="Third slide"
            />
          </Carousel.Item>
        </Carousel>
      </div>
    );
  }
}

export default LandingCarousel;
