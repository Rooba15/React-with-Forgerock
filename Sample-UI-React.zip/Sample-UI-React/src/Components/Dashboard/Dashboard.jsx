import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import "../Dashboard/Dashboard.scss";
import { connect } from "react-redux";
class Dashboard extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="Dashboard">
        <p>You are in dashboard!</p>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    ...ownProps,
    userObj: state.ui.userObj
  };
};

export default withRouter(
  connect(mapStateToProps, null)(Dashboard)
);
