import React, { Component } from 'react';
import './Container.scss';
import MainContent from "../MainContent/MainContent";

class Container extends Component {
    render() {
        return (
            <div className="Container row no-gutters">
                <div className="col-xs-0 col-sm-0 col-md-1 col-lg-1 col-xl-1"></div>
                <div className="Main-Content-Wrapper col-xs-12 col-sm-12 col-md-10 col-lg-10 col-xl-10">
                    <MainContent/>
                </div>
                <div className="col-xs-0 col-sm-0 col-md-1 col-lg-1 col-xl-1"></div>
            </div>
        );
    }
}

export default Container;