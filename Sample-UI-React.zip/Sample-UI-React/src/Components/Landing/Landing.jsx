import React, { Component } from "react";
import Container from "../Container/Container";
import "./Landing.scss";
import { connect } from "react-redux";
import { PropTypes } from "prop-types";

class Landing extends Component {
  render() {
    const { isMenuExpanded } = this.props;
    return (
      <div className={isMenuExpanded ? "LandingShrinked" : "Landing"}>
        <Container />
      </div>
    );
  }
}

Landing.propTypes = {
  isMenuExpanded: PropTypes.bool
};

const mapStateToProps = (state, ownProps) => {
  return {
    ...ownProps,
    isMenuExpanded: state.ui.isMenuExpanded
  };
};

export default connect(mapStateToProps)(Landing);
