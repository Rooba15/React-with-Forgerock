import React, { Component } from "react";
import { HttpClient } from '@forgerock/javascript-sdk';
import { SIDE_MENU_ITEMS } from "../../properties";
import Accordion from "react-bootstrap/Accordion";
import { connect } from "react-redux";
import { PropTypes } from "prop-types";
import {
  setAccordion,
  setToggleMenu,
  setToggleMobileMenu
} from "../../store/actions";
import John_Doe from "../../assets/images/john-doe.png";
import { withRouter } from "react-router";
import SettingsPopover from "./Popovers/SettingsPopover";
import NotificationsPopover from "./Popovers/NotificationsPopover";
import { Popover, OverlayTrigger, Tooltip } from "react-bootstrap";
import "./SideNav.scss";

class SideNav extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isAccordionOpen: false,
      selectedItem: "",
      isMobileMenu: false
    };
    this.selectMenuItem = this.selectMenuItem.bind(this);
    this.toggleMobileSideNav = this.toggleMobileSideNav.bind(this);
  }

  componentDidMount() {
    const { pathname } = this.props.location;
  }

  componentDidUpdate(prevProps, prevState) {
    const { location, isAccordionOpen } = this.props;
    if (isAccordionOpen !== prevState.isAccordionOpen) {
      this.setState({ isAccordionOpen: isAccordionOpen });
    }
  }

  selectMenuItem(itemUrl, sub_menu) {
    const { selectedItem } = this.state;
    const url = itemUrl.split("_")[0];
    if (selectedItem !== url) {
      this.setState({ selectedItem: url });
    }
    if (sub_menu) {
      this.setState({ isAccordionOpen: true }, () => {
        this.props.setAccordion(this.state.isAccordionOpen);
        this.props.setToggleMenu(this.state.isAccordionOpen);
      });
    }
  }

  toggleMobileSideNav() {
    console.log("Close button Clicked");
    const data = this.state.isMobileMenu;
    this.props.setToggleMobileMenu(data);
  }


  render() {
    //const fullName = getUser().profile.name;
    //const n = fullName.search("-");
    // const userName = fullName.slice(0, n);
    const userName = "name";
    const { selectedItem } = this.state;
    const {
      history,
      isMenuExpanded,
      isAccordionOpen,
      isMobileView,
      isMobileMenu
    } = this.props;

    return (
      <div
        className={
          isMobileView && isMobileMenu
            ? "MobileSideNav"
            : isMenuExpanded
              ? "SideNavExpanded"
              : "SideNav"
        }
      >
        <div className="Menu">
          <div className="UserInfo">
            <div className="User-Brief">
              <div className="User-Pic-Div">
                <div className="User-Pic">
                  <img src={John_Doe} alt="Dummy" />
                </div>
              </div>
              <div className="User-Title">{userName}</div>
            </div>
            <div className="User-Settings">
              <OverlayTrigger
                trigger="click"
                placement="bottom"
                rootClose={true}
                overlay={
                  <Popover>
                    <Popover.Content>
                      <NotificationsPopover />
                    </Popover.Content>
                  </Popover>
                }
              >
                <div className="c-icon--bell-o" />
              </OverlayTrigger>
              <OverlayTrigger
                trigger="click"
                placement="bottom"
                rootClose={true}
                overlay={
                  <Popover>
                    <Popover.Content>
                      <SettingsPopover />
                    </Popover.Content>
                  </Popover>
                }
              >
                <div className="c-icon--setting" />
              </OverlayTrigger>
            </div>
            {isMobileView === true && (
              <div className="closebtn" onClick={this.toggleMobileSideNav}>
                {" "}
                &times;
              </div>
            )}
          </div>
          <div className="MenuItemsContainer">
            <Accordion className="accordion">
              {SIDE_MENU_ITEMS.map((menuItem, index) => (
                <div
                  className="MenuItem"
                  key={index}
                  onClick={() =>
                    this.selectMenuItem(menuItem.url, menuItem.sub_menu)
                  }
                >
                  <Accordion.Toggle as={"div"} eventKey={index}>
                    <div
                      className={[
                        "menu-toggle",
                        selectedItem === menuItem.url ? "active" : " "
                      ].join(" ")}
                      onClick={() => history.push(menuItem.url)}
                    >
                      <div className="menu-icon">
                        <OverlayTrigger
                          placement="left"
                          overlay={<Tooltip>{menuItem.name}</Tooltip>}
                          popperConfig={{
                            modifiers: {
                              preventOverflow: {
                                enabled: false
                              },
                              hide: {
                                enabled: false
                              }
                            }
                          }}
                        >
                          <div className={menuItem.icon} />
                        </OverlayTrigger>
                      </div>

                      <div className="menu-name">{menuItem.name}</div>
                      {menuItem.sub_menu && (
                        <div
                          className={
                            isMobileView && isMobileMenu
                              ? "expand"
                              : isMenuExpanded
                                ? "expand"
                                : "expand-icon"
                          }
                        ></div>
                      )}
                    </div>
                  </Accordion.Toggle>
                  {isMenuExpanded === true &&
                    isAccordionOpen === true &&
                    menuItem.sub_menu && (
                      <Accordion.Collapse eventKey={index} key={index}>
                        <div className="menu-content">
                          {menuItem.sub_menu &&
                            menuItem.sub_menu.map((item, index) => (
                              <li
                                key={index}
                                onClick={() => history.push(item.url)}
                              >
                                {item.name}
                              </li>
                            ))}
                        </div>
                      </Accordion.Collapse>
                    )}
                </div>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    );
  }
}

SideNav.propTypes = {
  isMenuExpanded: PropTypes.bool,
  isAccordionOpen: PropTypes.bool,
  isMobileView: PropTypes.bool,
  isMobileMenu: PropTypes.bool
};

const mapStateToProps = (state, ownProps) => {
  return {
    ...ownProps,
    isMenuExpanded: state.ui.isMenuExpanded,
    isAccordionOpen: state.ui.isAccordionOpen,
    isMobileView: state.ui.isMobileView,
    isMobileMenu: state.data.isMobileMenu
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setAccordion: isAccordionOpen => dispatch(setAccordion(isAccordionOpen)),
    setToggleMenu: isMenuExpanded => dispatch(setToggleMenu(isMenuExpanded)),
    setToggleMobileMenu: isMobileMenu =>
      dispatch(setToggleMobileMenu(isMobileMenu))
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SideNav)
);
