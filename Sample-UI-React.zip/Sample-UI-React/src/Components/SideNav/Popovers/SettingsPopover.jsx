import React, { Component } from "react";
import { FRAuth, FRUser } from '@forgerock/javascript-sdk';
import { withRouter } from "react-router-dom";
import { SmallButton } from "../../Global/Buttons/Buttons";
import "./SettingsPopover.scss";
import { connect } from "react-redux";
import {
  setUserObj
} from "../../../store/actions";

class SettingsPopover extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }


  logout = async () => {
    try {
      await FRUser.logout();
      this.props.setUserObj(undefined);
      this.props.history.push("/login")
    } catch (error) {
      console.error(error)
    }
  }


  render() {
    const { history } = this.props;
    return (
      <div className="Settings-Popover container">
        <div className="heading mb-3 row">
          <p>User Settings/Information</p>
        </div>
        {/* <div className="phoneNumber row">
          <div className="title">Phone number</div>
          <div></div>
        </div>
        <div className="email row mt-4">
          <div className="title">Email</div>
          <div className="mb-4"></div>
        </div> */}
        {/* <div className="update row mt-4">
          <div
            className="update ml-4 col-12"
            onClick={() => history.push("/home/update-profile")}
          >
            Update Account Profile
          </div>
        </div> */}
        <div className="manage row mt-2">
          <div
            className="manage ml-4 col-12"
            onClick={() => history.push("/home/current-roles")}
          >
            View Roles & Access
          </div>
        </div>
        <div className="manage row mt-2">
          <div
            className="manage ml-4 col-12"
            onClick={() => history.push("/home/request-access")}
          >
            Request Access
          </div>
        </div>
        <div className="Button submit row mt-4">
          <SmallButton
            className="btn btn-small LogOut"
            type="submit"
            onClick={() => this.logout()}
          >
            LOGOUT
          </SmallButton>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    ...ownProps,
    userObj: state.ui.userObj
  };
};
const mapDispatchToProps = dispatch => {
  return {
    setUserObj: userObj => dispatch(setUserObj(userObj))
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(SettingsPopover)
);
