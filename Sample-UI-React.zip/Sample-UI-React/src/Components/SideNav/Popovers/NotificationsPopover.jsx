import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import { Card } from "react-bootstrap";
import { SmallButton } from "../../Global/Buttons/Buttons";
import { NOTIFICATIONS } from "../../../properties";
import "./NotificationsPopover.scss";

class NotificationsPopover extends Component {
  render() {
    const { history } = this.props;
    const length = NOTIFICATIONS.length;
    return (
      <div className="Notifications-Popover container">
        <div className="Notifications-heading-clear mb-3 row">
          <div className="col-7">
            <div className="heading">Notifications</div>
          </div>
          <div className="clearDiv col-5">
            <div className="clear">Clear</div>
          </div>
        </div>
        <div className="Notifications-status row">
          <div className="status mb-2">
            You have <span className="actionItems">{length}</span> item(s)
            waiting for you to take action.
          </div>
        </div>
        <div className="Button row">
          <SmallButton
            className="btn btn-small messageCenter"
            type="submit"
            onClick={() => history.push("/home/communication-hub/overview")}
          >
            Message Center
          </SmallButton>
        </div>
        <div className="Notifications-cards row card-row mt-3">
          <div>
            {NOTIFICATIONS.map((notification, index) => (
              <Card key={index}>
                <Card.Body className="card-body">
                  <div className="notification-card-title">
                    Application Access Request for <br />
                    <strong>
                      {notification.app_name} - <br />
                      {notification.sub_app}
                    </strong>
                  </div>
                  <div className="notification-card-requestor mt-2">
                    Submitted by {notification.requestor}
                  </div>
                  <div className="notification-card-submitted">
                    {notification.time} ago
                  </div>
                </Card.Body>
              </Card>
            ))}
          </div>
        </div>
        <div className="line row"></div>
        <div className="Notifications-manage row mt-2">
          <div
            className="manage ml-4 col-12"
            onClick={() => history.push("/home/communication-hub/settings")}
          >
            Manage User Notifications
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(NotificationsPopover);
