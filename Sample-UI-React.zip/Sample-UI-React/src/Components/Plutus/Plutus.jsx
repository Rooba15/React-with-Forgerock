import React, { Component } from "react";
import LandingPage from "../LandingPage/LandingPage";
import { Route, HashRouter as Router } from "react-router-dom";

class Plutus extends Component {
  render() {
    return (
      <div>
        <Router>
          <Route path="/" component={LandingPage} />
        </Router>
      </div>
    );
  }
}

export default Plutus;
