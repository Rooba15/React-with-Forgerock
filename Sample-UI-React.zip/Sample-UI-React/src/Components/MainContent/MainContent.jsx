import React, { Component } from "react";
import { FRAuth, Config, UserManager, FRUser, TokenManager, HttpClient } from '@forgerock/javascript-sdk';
import { Switch, Route } from "react-router-dom";
import Dashboard from "../Dashboard/Dashboard";
import { withRouter, Redirect } from "react-router-dom";
import Login from "../Login/Login";
import "./MainContent.scss";
import { connect } from "react-redux";
import {
  setUserObj
} from "../../store/actions";

class MainContent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.LandingDefaultPage = this.LandingDefaultPage.bind(this);
  }

  LandingDefaultPage() {
    return <Redirect to="/login" />;
  }

  render() {
    const history = this.props;
    return (
      <div className="Main-Content">
        <Switch history={history}>
          <Route exact path="/" render={this.LandingDefaultPage} />
          <Route path="/login" component={Login} />
          <Route path="/home/dashboard" component={Dashboard} />
        </Switch>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    ...ownProps,
    userObj: state.ui.userObj
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setUserObj: userObj => dispatch(setUserObj(userObj))
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(MainContent)
);