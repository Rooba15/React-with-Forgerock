import React, { Component } from "react";
import "./LandingPage.scss";
import Landing from "../Landing/Landing";
import SideNav from "../SideNav/SideNav";
import { PropTypes } from "prop-types";
import { setToggleMenu, setAccordion } from "../../store/actions";
import { connect } from "react-redux";

class LandingPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMenuExpanded: false
    };
    this.expandMenu = this.expandMenu.bind(this);
  }

  componentDidUpdate(prevState) {
    const { isMenuExpanded } = this.props;
    if (isMenuExpanded !== prevState.isMenuExpanded) {
      this.setState({ isMenuExpanded: isMenuExpanded });
    }
  }

  expandMenu = () => {
    this.setState(
      prevState => ({ isMenuExpanded: !prevState.isMenuExpanded }),
      () => {
        const data = this.state.isMenuExpanded;
        this.props.setToggleMenu(data);
        if (data === false) {
          this.props.setAccordion(data);
        }
      }
    );
  };

  render() {
    return (
      <div className="LandingPage">
        <Landing />
        <div className="Toggle-bar" onClick={this.expandMenu}>
          <div className="menuToggleBar"></div>
        </div>
        <div
          ref={node => {
            this.node = node;
          }}
        >
          <SideNav />
        </div>
      </div>
    );
  }
}

LandingPage.propTypes = {
  isMenuExpanded: PropTypes.bool
};

const mapStateToProps = (state, ownProps) => {
  return {
    ...ownProps,
    isMenuExpanded: state.ui.isMenuExpanded,
    isMobileMenu: state.data.isMobileMenu,
    isAccordionOpen: state.data.isAccordionOpen
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setToggleMenu: isMenuExpanded => dispatch(setToggleMenu(isMenuExpanded)),
    setAccordion: isAccordionOpen => dispatch(setAccordion(isAccordionOpen))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(LandingPage);
