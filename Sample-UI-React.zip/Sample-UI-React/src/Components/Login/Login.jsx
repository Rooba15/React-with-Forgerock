import { FRAuth, Config, UserManager, FRUser, TokenManager, HttpClient } from '@forgerock/javascript-sdk';
import React from 'react';
import "./Login.scss";
import CircularProgress from "@material-ui/core/CircularProgress";
import Button from "@material-ui/core/Button";
import PlutusLogin from "../../assets/images/PlutusLogin.png";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import {
  FormControl,
  InputLabel,
  Input,
  InputAdornment
} from "@material-ui/core";
import {
  setUserObj
} from "../../store/actions";

class Login extends React.Component {
  constructor(props) {
    super(props);
    // this.UserDiv = React.createRef();
    // this.UserInfo = React.createRef();
    // Initialize application state
    this.state = {
      UserInfo: "undefined",
      accessToken: "undefined",
      forgerockState: {
        error: undefined,
        ssoToken: undefined,
        step: undefined,
      },
      isLoading: false,
      error: false,
    };
  }

  componentDidMount() {
    console.log(this.props.history.location)
    if (this.props.userObj) {
      // DO not run authentication when the user info is there in store
    } else {
      if (this.props.history.location.pathname === "/login") {
        // Set configuration defaults
        Config.set({
          clientId: 'a8abc33ef891071f9256cee892b8719e',
          redirectUri: 'http://localhost:3002/callback',
          scope: 'openid profile me.read',
          serverConfig: { baseUrl: 'https://openam-aim.forgeblocks.com/am' },
          tree: 'UsernamePassword',
        });

        // Start the authentication flow
        this.nextStep();
      }
    }
  }

  nextStep = async (step) => {
    // Get the next step in this authentication tree
    step = await FRAuth.next(step).catch(this.onError);

    // Update application state based on the response
    let ssoToken, error;
    if (step.type === 'LoginSuccess') {
      ssoToken = step.getSessionToken();
      const tokens = await TokenManager.getTokens({ forceRenew: true });
      const user = await UserManager.getCurrentUser();

      this.showUser(user, tokens);
    } else if (step.type === 'LoginFailure') {
      error = step.getCode();
      if (error === 401) {
        this.setState({ error: true });
      }
    }
    this.setState({ forgerockState: { step, ssoToken, error } });
  };

  showUser = (user, tokens) => {
    this.setState({ UserInfo: JSON.stringify(user, null, 2) });
    this.setState({ accessToken: tokens });
    let authObj = {
      tokens: tokens,
      user: user
    }
    this.props.setUserObj(authObj);
    this.props.history.push("/home/dashboard")
  }

  onError = (error) => {
    this.setState({ forgerockState: { error } });
  };

  logout = async () => {
    try {
      await FRUser.logout();
      window.location.reload(true);
    } catch (error) {
      console.error(error)
    }
  }
  onErrorHide = () => {
    this.setState({
      error: false
    });
  }

  render() {
    console.log(this.state.forgerockState)
    // Handle init/success/failure states
    if (!this.state.forgerockState.step) {
      return <p>Loading...</p>;
    } else if (this.state.forgerockState.ssoToken) {
      return <div>Authenticated! <div id="User">
        <div>Your user information:
        <pre>{this.state.UserInfo}</pre>
        </div>
        <div>access token:
        <pre>{this.state.accessToken.accessToken}</pre>
        </div>
        <div>id token:
        <pre>{this.state.accessToken.idToken}</pre>
        </div>
        <div>Refresh token:
        <pre>{this.state.accessToken.refreshToken}</pre>
        </div>
        <button onClick={() => this.logout()}>Sign Out</button>
      </div></div>;
    } else if (this.state.forgerockState.error) {
      return <p>Error: {this.state.forgerockState.error}</p>;
    } else {
      // Otherwise, select the correct component for this step
      const stage = this.state.forgerockState.step.getStage();
      return (
        <>
          {console.log(stage)}
          {/* {stage == 'UsernamePassword' && ( */}
          <UsernamePassword step={this.state.forgerockState.step} onSubmit={this.nextStep} />
          {/* )} */}
          {/* Create similar components for other stages */}
        </>
      );
    }


  }
}

// Custom UI for rendering the "UsernamePassword" step
function UsernamePassword(props) {
  const setUsername = (e) => {
    const cb = props.step.getCallbackOfType('NameCallback');
    cb.setName(e.target.value);
  };

  const setPassword = (e) => {
    const cb = props.step.getCallbackOfType('PasswordCallback');
    cb.setPassword(e.target.value);
  };

  const onSubmit = () => {
    props.onSubmit(props.step);
  };

  return (
    <>
      <div className="Login">
        <div className="Login-Image row">
          <div className="First-Col col-xs-0 col-sm-0 col-md-0 col-lg-6 col-xl-6">
            <img src={PlutusLogin} alt="Login" className="img-fluid" />
          </div>
          <div className="Second-Col col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
            <div className="Login-Header">
              <div className="App-Title col-12">
                <span className="a-neo-medium">Allianz</span> Investment
                Management
              </div>
            </div>
            <form className="Login-Details" >
              <div className="row">
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
                <div className="Log-In col-xs-10 col-sm-10 col-md-6 col-lg-8 col-xl-6">
                  Log In
                </div>
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
              </div>
              <div className="row">
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
                <div className="Sign-Intro col-xs-10 col-sm-10 col-md-6 col-lg-8 col-xl-6">
                  Sign in to continue with Plutus
                </div>
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
              </div>

              <div className="row">
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
                <div className="UserName col-xs-10 col-sm-10 col-md-6 col-lg-8 col-xl-6">
                  <FormControl>
                    <InputLabel>Username</InputLabel>
                    <Input
                      type="text"
                      onChange={setUsername}
                      required
                      endAdornment={
                        <InputAdornment position="end">
                          <span className="Adornment c-icon--user-o"></span>
                        </InputAdornment>
                      }
                    />
                  </FormControl>
                </div>
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
              </div>
              <div className="row">
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
                <div className="Password col-xs-10 col-sm-10 col-md-6 col-lg-8 col-xl-6">
                  <FormControl>
                    <InputLabel>Password</InputLabel>
                    <Input
                      type="password"
                      required
                      onChange={setPassword}
                      endAdornment={
                        <InputAdornment position="end">
                          <span className="Adornment c-icon--lock-o"></span>
                        </InputAdornment>
                      }
                    />
                  </FormControl>
                </div>
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
              </div>
              <div className="row">
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
                <div className="Button-Col col-xs-10 col-sm-10 col-md-6 col-lg-8 col-xl-6">
                  <Button
                    type="submit"
                    variant="contained"
                    className="login-button"
                    onClick={onSubmit}
                  >
                    Log in
                  </Button>
                </div>
                <div className="col-xs-1 col-sm-1 col-md-3 col-lg-2 col-xl-3" />
              </div>
            </form>
            <div className="login-footer">
              <div className="row">
                <div className="footer-copyright col-12">
                  Copyright &copy; Allianz 2019&nbsp;&nbsp;|&nbsp;&nbsp;Powered
                  by AIM IT
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
const mapStateToProps = (state, ownProps) => {
  return {
    ...ownProps,
    userObj: state.ui.userObj
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setUserObj: userObj => dispatch(setUserObj(userObj))
  };
};

export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(Login)
);