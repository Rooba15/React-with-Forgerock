export const SIDE_MENU_ITEMS = [
  {
    id: 1,
    name: "Dashboard",
    sub_menu: false,
    icon: "icon-c-icon--squares",
    url: "/home/dashboard"
  }
];



export const NOTIFICATIONS = [
  {
    id: 1,
    app_name: "Ethics and Compliance",
    sub_app: "Books and Records",
    requestor: "Jimmy Robertson",
    time: "12 min"
  },
  {
    id: 2,
    app_name: "Reconcililation",
    sub_app: "",
    requestor: "Andrea Jamison",
    time: "1 day(s)"
  },
  {
    id: 3,
    app_name: "Ethics and Compliance",
    sub_app: "Books and Records",
    requestor: "Julian Trent",
    time: "2 day(s)"
  },
  {
    id: 4,
    app_name: "Investment Operations",
    sub_app: "",
    requestor: "Andy Dwyer",
    time: "5 day(s)"
  }
];